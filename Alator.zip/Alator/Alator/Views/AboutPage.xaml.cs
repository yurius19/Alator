﻿using System;

using Xamarin.Forms;

namespace Alator
{
    public partial class AboutPage : ContentPage
    {
        public AboutPage()
        {
            InitializeComponent();
        }
    }
}
